#Install Packages

install.packages("rvest")
install.packages("dplyr")
install.packages("httr")
install.packages("ggplot2")
install.packages("askpass")
install.packages("curl")
install.packages("tidyverse")

#Loading the Packages
library(rvest)
library(dplyr)
library(httr)
library(ggplot2)
library(askpass)
library(curl)
library(tidyverse)


#-------------------------------------------------------------------------------
#Specifying the url for desired website to be scaped
url <- 'https://www.imdb.com/search/title/?genres=Thriller&explore=genres&title_type=feature&ref_=ft_movie_20'

#Reading the HTML code from the website
webpage <- read_html(url)


#-------------------------------------------------------------------------------

#scraping the following data

#Title, #Description, #Runtime, #Genre, #Rating, #Votes, #Actor, #Metascore, #Director, #Rank


#-------------------------------------------------------------------------------
#Step 1 :Title

#used Selector Gadet : http://selectorgadget.com
#Select first Title and right-click and (Copy) the XPath code; Making sure to select the desired is acurate

title_data_html <- html_nodes(webpage,'.lister-item-header a')
title_data <- html_text(title_data_html)
head(title)
tail(title)

#-------------------------------------------------------------------------------

#Step 2: Description

description_data_html <- html_nodes(webpage,'.ratings-bar+ .text-muted')
description_data <- html_text(description_data_html)
head(description_data)
tail(description_data)

#-------------------------------------------------------------------------------

#Step 3: Runtime

runtime_data_html <- html_nodes(webpage,'.runtime')
runtime_data <- html_text(runtime_data_html)
head(runtime_data)
tail(runtime_data)

#Data-Preprocessing: removing mins and converting it to numerical value
runtime_data <-gsub("min,"",runtime_data)
runutime_data <- as.numeric(runtime_data)

#Rerun the runtime data
head(runtime_data)
tail(runtime_data)

#-------------------------------------------------------------------------------
#Step 4: Genre

genre_data_html <- html_nodes(webpage,'.genre')
genre_data <- html_text(genre_data_html)
head(genre_data)
tail(genre_data)

#Data-Preprocessing: removing /n

genre_data<-gsub("\n","",genre_data)

#Removing excessive spaces
genre_data<-gsub("","",genre_data)

#Using the first genre only
genre_data<-gsub(",.*","",genre_data)

#Conversion each genre from text to factors
genre_data <-as.factor(genre_data)

#Update Genre data
tail(genre_data)

#-------------------------------------------------------------------------------

#Step 5: Rating

rating_data_html <-html_nodes(webpage,'.imbd-rating,strong')
rating_data <-html_nodes(rating_data_html)
head(rating_data)
tail(rating_data)

#Data Preprocessing: conversion from ratings to numerical value
rating_data <-as.numeric(rating_data)

#Refreash Ratings data
head(rating_data)
tail(rating_data)

#-------------------------------------------------------------------------------

#Step 6: Votes

votes_data_html <- html_nodes(webpage,'.sort-num_votes-visible span:nth-child(1)')
votes_data <- html_text(votes_data_html)
head(votes_data)
tail(votes_data)

#Data Preprocessing: removing commas

votes_data <-gsub(",","",votes_data)

#Conversion from votes to numerical value

votes_data <-as.numeric(votes_data)

#Update Votes

head(votes_data)
tail(votes_data)

#-------------------------------------------------------------------------------

#Step 7: Actors

actors_data_html <- html_nodes(webpage, '.lister-item-content .ghost+a')
actors_data <- html_text(actors_data_html)
head(actors_data)
tail(actors_data)

#Data Preprocessing: Conversion from data into factors
actors_data <-as.factor(actors_data)

#Update Actors Data
head(actors_data)
tail(actors_data)

#-------------------------------------------------------------------------------

#Step 8: Metascores
metascore_data_html <- html_nodes(webpage, '.ratings-metascore')
metascore_data <- html_text(metascore_data_html)
head(metascore_data)
tail(metascore_data)

#Data Preprocessing: removing excess space within
metascore_data <-gsub(" ","" ,metascore_data_html)

#Update Metascore data

head(metascore_data)
tail(metascore_data)

#Lets check the length of metascore data
length(metascore_data)

for (i in c(5,11,18,19,21,23,24,25,28,33,38,39,40,41,45,50)) #Checked manually
{
  a<-metascore_data[1:(i-1)]
  b<-metascore_data[i:length(metascore_data)]
  metascore_data<-append(a,list("NA"))
  metascore_data<-append(metascore_data,b)
}
#View warnings
warnings(metascore_data)

#Data Preprocessing: conversion metascore to numerical value
metascore_data <-as.numeric(metascore_data)

#Print numerical output
print(metascore_data)

#Update length of metascore
length(metascore_data)

#Summarize
summary(metascore_data)

#-------------------------------------------------------------------------------

#Step 9: Director

directors_data_html <- html_nodes(webpage,'.text-muted+ p a:nth-child(1)')
directors_data <- html_text(directors_data_html)
head(directors_data)
tail(directors_data)

#Data Preprocessing: conversion from data to factors

directors_data <-as.factor(directors_data)

#Update Directors

head(directors_data)
tail(directors_data)

#-------------------------------------------------------------------------------

Step 10: Rank

#CSS sselector to scrap rank section
rank_data_html <- html_nodes(webpage,'.text-primary')

#Conversion rankings to text
rank_data <-html_text(rank_data_html)

#Rankings list
head(rank_data)
tail(rank_data)

#Data Preprocessing: converting rank scores to numerical value
rank_data <-as.numeric(rank_data)

#Update Rankings
head(rank_data)
tail(rank_data)

#-------------------------------------------------------------------------------


#Final Step: Setting up data frame

dr <- summary(movie_data.total$director)

movies_df<-data.frame(Title = title_data, Description = description_data, Runtime = runtime_data, Genre = genre_data, Rating = rating_data, Votes = votes_data, Actors = actors_data, Metascore = metascore_data, Director = directors_data, Rank = rank_data)

#Finalization of data frame
str(movies_df)

##
### Some Result
###
#Analyse 100 Move Data
#which genre has the highest votes
ggplot(movies_df,aes(x=Runtime,Y=Rating)) + geom_point(aes(size=Votes,col=Genre))

#which Genre had the longest runtime
qplot(data = movies_df,Runtime,fill = Genre, bins - 30)

#Which actor stared in majority of the films
ggplot(movies_df,aes(x=Runtime,Y=Votes)) + geom_point(aes(size=Actor,col=Rank))